﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class AjoutParent : Form
    {
        private static Planing pln = new Planing();
        private static Tache tch = new Tache();
        private static int i = 0;
        public AjoutParent()
        {
            InitializeComponent();
        }

        private void AjoutParent_Load(object sender, EventArgs e)
        {

        }

        private void bt_enregister_Click(object sender, EventArgs e)
        {
            Parent p = new Parent();
            UserCible u = new UserCible();
            Planing pl = new Planing();
            Tache ta = new Tache();
            if (i == 0)
            {
                
                try
                {
                    Connexion.ProjetDB.Parent.InsertOnSubmit(p);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception e02)
                {
                    MessageBox.Show(e02.Message);
                }
                try
                {
                    u.Id_parent = p.Id_parent;
                    Connexion.ProjetDB.UserCible.InsertOnSubmit(u);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception e03)
                {
                    MessageBox.Show(e03.Message);
                }
                try
                {
                    pl.Id_usercreator = u.Id_usercible;
                    Connexion.ProjetDB.Planing.InsertOnSubmit(pl);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Planing enrégistré avec succé.");
                }
                catch (Exception ex1)
                {
                    MessageBox.Show(ex1.Message);
                }
                ta.Id_planing = pln.Id_planing;
                ta.nom_tache = txt_nomtache.Text;
                ta.date_debut = dateTimePicker1.Value;
                ta.date_fin = dateTimePicker2.Value;
                ta.duree_tolerance = txt_tolerance.Text;
                ta.emplacement = txt_emplacement.Text;
                ta.personnes_impliques = txt_personneimplique.Text;
                ta.description = cmb_description.Text;
                ta.type_tache = cmb_type.Text;
                try
                {
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    //Connexion.ProjetDB.Planings.InsertOnSubmit(pln);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Planing enrégistré avec succé.");
                    tch = ta;
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
                i++;
                pln = pl;
                this.Close();
            }
            else
            {
                ta.Id_planing = pln.Id_planing;
                ta.nom_tache = txt_nomtache.Text;
                ta.date_debut = dateTimePicker1.Value;
                ta.date_fin = dateTimePicker2.Value;
                ta.duree_tolerance = txt_tolerance.Text;
                ta.emplacement = txt_emplacement.Text;
                ta.personnes_impliques = txt_personneimplique.Text;
                ta.description = cmb_description.Text;
                ta.type_tache = cmb_type.Text;
                try
                {
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    //Connexion.ProjetDB.Planings.InsertOnSubmit(pln);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Planing enrégistré avec succé.");
                    this.Close();
                    tch = ta;
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
                this.Close();
            }
        }

        private void bt_ajouttache_Click(object sender, EventArgs e)
        {
            Parent p = new Parent();
            UserCible u = new UserCible();
            Planing pl = new Planing();
            Tache ta = new Tache();
            if (i == 0)
            {
                try
                {
                    Connexion.ProjetDB.Parent.InsertOnSubmit(p);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception e02)
                {
                    MessageBox.Show(e02.Message);
                }
                try
                {
                    u.Id_parent = p.Id_parent;
                    Connexion.ProjetDB.UserCible.InsertOnSubmit(u);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception e03)
                {
                    MessageBox.Show(e03.Message);
                }
                try
                {
                    pl.Id_usercreator = u.Id_usercible;
                    Connexion.ProjetDB.Planing.InsertOnSubmit(pl);
                    Connexion.ProjetDB.SubmitChanges();
                    //MessageBox.Show("Planing enrégistré avec succé.");
                    pln = pl;
                }
                catch (Exception ex1)
                {
                    MessageBox.Show(ex1.Message);
                }
                ta.Id_planing = pln.Id_planing;
                ta.nom_tache = txt_nomtache.Text;
                ta.date_debut = dateTimePicker1.Value;
                ta.date_fin = dateTimePicker2.Value;
                ta.duree_tolerance = txt_tolerance.Text;
                ta.emplacement = txt_emplacement.Text;
                ta.personnes_impliques = txt_personneimplique.Text;
                ta.description = cmb_description.Text;
                ta.type_tache = cmb_type.Text;
                try
                {
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    //Connexion.ProjetDB.Planings.InsertOnSubmit(pln);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Planing enrégistré avec succé.");
                    this.Close();
                    tch = ta;
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
                txt_nomtache.Text = "";
                txt_tolerance.Text = "";
                txt_emplacement.Text = "";
                txt_personneimplique.Text = "";
                cmb_description.Text = "";
                cmb_type.Text = "";
                i++;
            }
            else
            {
                try
                {
                    ta.Id_planing = pln.Id_planing;
                    ta.nom_tache = txt_nomtache.Text;
                    ta.date_debut = dateTimePicker1.Value;
                    ta.date_fin = dateTimePicker2.Value;
                    ta.duree_tolerance = txt_tolerance.Text;
                    ta.emplacement = txt_emplacement.Text;
                    ta.personnes_impliques = txt_personneimplique.Text;
                    ta.description = cmb_description.Text;
                    ta.type_tache = cmb_type.Text;
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Tache enrégistré avec succé.");
                    tch = ta;
                    txt_nomtache.Text = "";
                    txt_tolerance.Text = "";
                    txt_emplacement.Text = "";
                    txt_personneimplique.Text = "";
                    cmb_description.Text = "";
                    cmb_type.Text = "";
                }
                catch (Exception exe)
                {
                    MessageBox.Show(exe.Message);
                }
            }
        }
    }
}
