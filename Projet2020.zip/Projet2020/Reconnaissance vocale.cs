﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
namespace Projet2020
{
    public partial class Reconnaissance_vocale : Form
    {
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        public Reconnaissance_vocale()
        {
            InitializeComponent();
        }

        private void Reconnaissance_vocale_Load(object sender, EventArgs e)
        {
            Choices commands = new Choices();
            commands.Add(new string[] { "My planing", "modify my information", "statistic","list des conjoint","list of parents","list of child","list of user", "user creator","list of planing","list of task" });
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(commands);
            Grammar grammar = new Grammar(gBuilder);
            recEngine.LoadGrammarAsync(grammar);
            recEngine.SetInputToDefaultAudioDevice();
            recEngine.SpeechRecognized += recEngine_SpeechRecognized;
        }

        private void recEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            switch (e.Result.Text)
            {
                case "My planing":
                    AfficharPlaning aff = new AfficharPlaning();
                    aff.Show();
                    break;
                case "modify my information":
                    ModifierPlaningUser m = new ModifierPlaningUser();
                    m.Show();
                    break;
                case "statistic":
                    Statistiqueparjour s = new Statistiqueparjour();
                    s.Show();
                    break;
                case "list des conjoint":
                    ListConjoint l = new ListConjoint();
                    l.Show();
                    break;
                case "list of parents":
                    ListParent l1 = new ListParent();
                    l1.Show();
                    break;
                case "list of child":
                    ListEnfant l2 = new ListEnfant();
                    l2.Show();
                    break;
                case "list of user":
                    ListofUser l3 = new ListofUser();
                    l3.Show();
                    break;
                case "user creator":
                    ListOfUserCible l4 = new ListOfUserCible();
                    l4.Show();
                    break;
                case "list of planing":
                    ListOfPlanings l5 = new ListOfPlanings();
                    l5.Show();
                    break;
                case "list of task":
                    ListOfTasks l6 = new ListOfTasks();
                    l6.Show();
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            recEngine.RecognizeAsync(RecognizeMode.Multiple);
            btn_disable.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            recEngine.RecognizeAsyncStop();
            btn_disable.Enabled = false;
        }
    }
}
