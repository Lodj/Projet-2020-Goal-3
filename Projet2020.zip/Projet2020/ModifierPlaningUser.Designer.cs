﻿namespace Projet2020
{
    partial class ModifierPlaningUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rd_nevinantpasavecparent = new System.Windows.Forms.RadioButton();
            this.rd_vivantavecparent = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rd_celibataire = new System.Windows.Forms.RadioButton();
            this.rd_marie = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rd_feminin = new System.Windows.Forms.RadioButton();
            this.rd_masculin = new System.Windows.Forms.RadioButton();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_motdepasse = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_login01 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.bt_enregistrer = new System.Windows.Forms.Button();
            this.txt_nbreenfant = new System.Windows.Forms.TextBox();
            this.txt_adresse = new System.Windows.Forms.TextBox();
            this.dtp_datenaiss = new System.Windows.Forms.DateTimePicker();
            this.txt_fonction01 = new System.Windows.Forms.TextBox();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.txt_nom = new System.Windows.Forms.TextBox();
            this.txt_prenom = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txt_motdepasse);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txt_login01);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.bt_enregistrer);
            this.groupBox1.Controls.Add(this.txt_nbreenfant);
            this.groupBox1.Controls.Add(this.txt_adresse);
            this.groupBox1.Controls.Add(this.dtp_datenaiss);
            this.groupBox1.Controls.Add(this.txt_fonction01);
            this.groupBox1.Controls.Add(this.txt_mail);
            this.groupBox1.Controls.Add(this.txt_nom);
            this.groupBox1.Controls.Add(this.txt_prenom);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(563, 518);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rd_nevinantpasavecparent);
            this.groupBox5.Controls.Add(this.rd_vivantavecparent);
            this.groupBox5.Location = new System.Drawing.Point(138, 370);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(200, 40);
            this.groupBox5.TabIndex = 84;
            this.groupBox5.TabStop = false;
            // 
            // rd_nevinantpasavecparent
            // 
            this.rd_nevinantpasavecparent.AutoSize = true;
            this.rd_nevinantpasavecparent.Location = new System.Drawing.Point(120, 17);
            this.rd_nevinantpasavecparent.Name = "rd_nevinantpasavecparent";
            this.rd_nevinantpasavecparent.Size = new System.Drawing.Size(45, 17);
            this.rd_nevinantpasavecparent.TabIndex = 24;
            this.rd_nevinantpasavecparent.TabStop = true;
            this.rd_nevinantpasavecparent.Text = "Non";
            this.rd_nevinantpasavecparent.UseVisualStyleBackColor = true;
            // 
            // rd_vivantavecparent
            // 
            this.rd_vivantavecparent.AutoSize = true;
            this.rd_vivantavecparent.Location = new System.Drawing.Point(6, 17);
            this.rd_vivantavecparent.Name = "rd_vivantavecparent";
            this.rd_vivantavecparent.Size = new System.Drawing.Size(41, 17);
            this.rd_vivantavecparent.TabIndex = 22;
            this.rd_vivantavecparent.TabStop = true;
            this.rd_vivantavecparent.Text = "Oui";
            this.rd_vivantavecparent.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rd_celibataire);
            this.groupBox3.Controls.Add(this.rd_marie);
            this.groupBox3.Location = new System.Drawing.Point(138, 305);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 40);
            this.groupBox3.TabIndex = 83;
            this.groupBox3.TabStop = false;
            // 
            // rd_celibataire
            // 
            this.rd_celibataire.AutoSize = true;
            this.rd_celibataire.Location = new System.Drawing.Point(120, 17);
            this.rd_celibataire.Name = "rd_celibataire";
            this.rd_celibataire.Size = new System.Drawing.Size(74, 17);
            this.rd_celibataire.TabIndex = 21;
            this.rd_celibataire.TabStop = true;
            this.rd_celibataire.Text = "Célibataire";
            this.rd_celibataire.UseVisualStyleBackColor = true;
            this.rd_celibataire.CheckedChanged += new System.EventHandler(this.rd_celibataire_CheckedChanged);
            // 
            // rd_marie
            // 
            this.rd_marie.AutoSize = true;
            this.rd_marie.Location = new System.Drawing.Point(6, 17);
            this.rd_marie.Name = "rd_marie";
            this.rd_marie.Size = new System.Drawing.Size(51, 17);
            this.rd_marie.TabIndex = 19;
            this.rd_marie.TabStop = true;
            this.rd_marie.Text = "Marié";
            this.rd_marie.UseVisualStyleBackColor = true;
            this.rd_marie.CheckedChanged += new System.EventHandler(this.rd_marie_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rd_feminin);
            this.groupBox2.Controls.Add(this.rd_masculin);
            this.groupBox2.Location = new System.Drawing.Point(139, 181);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(199, 40);
            this.groupBox2.TabIndex = 82;
            this.groupBox2.TabStop = false;
            // 
            // rd_feminin
            // 
            this.rd_feminin.AutoSize = true;
            this.rd_feminin.Location = new System.Drawing.Point(120, 17);
            this.rd_feminin.Name = "rd_feminin";
            this.rd_feminin.Size = new System.Drawing.Size(61, 17);
            this.rd_feminin.TabIndex = 18;
            this.rd_feminin.TabStop = true;
            this.rd_feminin.Text = "Féminin";
            this.rd_feminin.UseVisualStyleBackColor = true;
            // 
            // rd_masculin
            // 
            this.rd_masculin.AutoSize = true;
            this.rd_masculin.Location = new System.Drawing.Point(6, 19);
            this.rd_masculin.Name = "rd_masculin";
            this.rd_masculin.Size = new System.Drawing.Size(67, 17);
            this.rd_masculin.TabIndex = 16;
            this.rd_masculin.TabStop = true;
            this.rd_masculin.Text = "Masculin";
            this.rd_masculin.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.DarkRed;
            this.label24.Location = new System.Drawing.Point(389, 425);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(102, 13);
            this.label24.TabIndex = 81;
            this.label24.Text = "*Saisir mot de passe";
            this.label24.Visible = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.DarkRed;
            this.label23.Location = new System.Drawing.Point(389, 391);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(156, 13);
            this.label23.TabIndex = 80;
            this.label23.Text = "*Viviez-vous avec vos parents?";
            this.label23.Visible = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.DarkRed;
            this.label22.Location = new System.Drawing.Point(389, 358);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(156, 13);
            this.label22.TabIndex = 79;
            this.label22.Text = "*Combien d\'enfants avez-vous?";
            this.label22.Visible = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.DarkRed;
            this.label21.Location = new System.Drawing.Point(388, 324);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(105, 13);
            this.label21.TabIndex = 78;
            this.label21.Text = "*Saisir votre etat civil";
            this.label21.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.DarkRed;
            this.label20.Location = new System.Drawing.Point(389, 286);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(103, 13);
            this.label20.TabIndex = 77;
            this.label20.Text = "*Saisir votre adresse";
            this.label20.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.DarkRed;
            this.label19.Location = new System.Drawing.Point(389, 260);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(97, 13);
            this.label19.TabIndex = 76;
            this.label19.Text = "*Saisir adresse mail";
            this.label19.Visible = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.DarkRed;
            this.label18.Location = new System.Drawing.Point(391, 234);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 13);
            this.label18.TabIndex = 75;
            this.label18.Text = "*Saisir votre fonction";
            this.label18.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.DarkRed;
            this.label17.Location = new System.Drawing.Point(389, 202);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 13);
            this.label17.TabIndex = 74;
            this.label17.Text = "*Saisir genre";
            this.label17.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.DarkRed;
            this.label16.Location = new System.Drawing.Point(389, 153);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 13);
            this.label16.TabIndex = 73;
            this.label16.Text = "*Saisir date de naissance";
            this.label16.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.DarkRed;
            this.label15.Location = new System.Drawing.Point(389, 125);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 13);
            this.label15.TabIndex = 72;
            this.label15.Text = "*Saisir nom";
            this.label15.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.DarkRed;
            this.label14.Location = new System.Drawing.Point(389, 99);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 13);
            this.label14.TabIndex = 71;
            this.label14.Text = "*Saisir prénom";
            this.label14.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.DarkRed;
            this.label13.Location = new System.Drawing.Point(389, 71);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 13);
            this.label13.TabIndex = 70;
            this.label13.Text = "*Saisir login";
            this.label13.Visible = false;
            // 
            // txt_motdepasse
            // 
            this.txt_motdepasse.Location = new System.Drawing.Point(139, 416);
            this.txt_motdepasse.Name = "txt_motdepasse";
            this.txt_motdepasse.Size = new System.Drawing.Size(199, 20);
            this.txt_motdepasse.TabIndex = 69;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 425);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 13);
            this.label12.TabIndex = 68;
            this.label12.Text = "Mot de passe";
            // 
            // txt_login01
            // 
            this.txt_login01.Location = new System.Drawing.Point(139, 65);
            this.txt_login01.Name = "txt_login01";
            this.txt_login01.Size = new System.Drawing.Size(199, 20);
            this.txt_login01.TabIndex = 67;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 72);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 66;
            this.label11.Text = "Login";
            // 
            // bt_enregistrer
            // 
            this.bt_enregistrer.Location = new System.Drawing.Point(197, 461);
            this.bt_enregistrer.Name = "bt_enregistrer";
            this.bt_enregistrer.Size = new System.Drawing.Size(75, 38);
            this.bt_enregistrer.TabIndex = 65;
            this.bt_enregistrer.Text = "Modifier";
            this.bt_enregistrer.UseVisualStyleBackColor = true;
            this.bt_enregistrer.Click += new System.EventHandler(this.bt_enregistrer_Click);
            // 
            // txt_nbreenfant
            // 
            this.txt_nbreenfant.Location = new System.Drawing.Point(139, 351);
            this.txt_nbreenfant.Name = "txt_nbreenfant";
            this.txt_nbreenfant.Size = new System.Drawing.Size(199, 20);
            this.txt_nbreenfant.TabIndex = 64;
            this.txt_nbreenfant.Visible = false;
            // 
            // txt_adresse
            // 
            this.txt_adresse.Location = new System.Drawing.Point(139, 279);
            this.txt_adresse.Name = "txt_adresse";
            this.txt_adresse.Size = new System.Drawing.Size(199, 20);
            this.txt_adresse.TabIndex = 63;
            // 
            // dtp_datenaiss
            // 
            this.dtp_datenaiss.Location = new System.Drawing.Point(139, 146);
            this.dtp_datenaiss.Name = "dtp_datenaiss";
            this.dtp_datenaiss.Size = new System.Drawing.Size(200, 20);
            this.dtp_datenaiss.TabIndex = 62;
            // 
            // txt_fonction01
            // 
            this.txt_fonction01.Location = new System.Drawing.Point(139, 227);
            this.txt_fonction01.Name = "txt_fonction01";
            this.txt_fonction01.Size = new System.Drawing.Size(199, 20);
            this.txt_fonction01.TabIndex = 61;
            // 
            // txt_mail
            // 
            this.txt_mail.Location = new System.Drawing.Point(138, 253);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(200, 20);
            this.txt_mail.TabIndex = 60;
            this.txt_mail.Text = "ibrahimadiallo971@hotmail.com";
            // 
            // txt_nom
            // 
            this.txt_nom.Location = new System.Drawing.Point(140, 118);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(199, 20);
            this.txt_nom.TabIndex = 59;
            // 
            // txt_prenom
            // 
            this.txt_prenom.Location = new System.Drawing.Point(139, 92);
            this.txt_prenom.Name = "txt_prenom";
            this.txt_prenom.Size = new System.Drawing.Size(199, 20);
            this.txt_prenom.TabIndex = 58;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 389);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(119, 13);
            this.label10.TabIndex = 57;
            this.label10.Text = "Vivant avec tes parents";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 358);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 13);
            this.label9.TabIndex = 56;
            this.label9.Text = "Nombre d\'enfant(s)";
            this.label9.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 324);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 55;
            this.label8.Text = "Etat Civil";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 286);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 54;
            this.label7.Text = "Adresse";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 53;
            this.label6.Text = "Adresse mail";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 227);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 52;
            this.label5.Text = "Fonction";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 51;
            this.label4.Text = "Genre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "Date de naissance";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 49;
            this.label2.Text = "Nom";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 48;
            this.label1.Text = "Prénom";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(13, 42);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(117, 13);
            this.label25.TabIndex = 85;
            this.label25.Text = "Donner votre identifiant";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(139, 39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 20);
            this.textBox1.TabIndex = 86;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.DarkRed;
            this.label26.Location = new System.Drawing.Point(391, 46);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(111, 13);
            this.label26.TabIndex = 87;
            this.label26.Text = "*Saisir votre identifiant";
            this.label26.Visible = false;
            // 
            // ModifierPlaningUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 542);
            this.Controls.Add(this.groupBox1);
            this.Name = "ModifierPlaningUser";
            this.Text = "ModifierPlaningUser";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rd_nevinantpasavecparent;
        private System.Windows.Forms.RadioButton rd_vivantavecparent;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rd_celibataire;
        private System.Windows.Forms.RadioButton rd_marie;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rd_feminin;
        private System.Windows.Forms.RadioButton rd_masculin;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_motdepasse;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_login01;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button bt_enregistrer;
        private System.Windows.Forms.TextBox txt_nbreenfant;
        private System.Windows.Forms.TextBox txt_adresse;
        private System.Windows.Forms.DateTimePicker dtp_datenaiss;
        private System.Windows.Forms.TextBox txt_fonction01;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.TextBox txt_nom;
        private System.Windows.Forms.TextBox txt_prenom;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
    }
}