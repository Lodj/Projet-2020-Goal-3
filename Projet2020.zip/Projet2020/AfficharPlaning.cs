﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class AfficharPlaning : Form
    {
        public AfficharPlaning()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            var lst3 = from x in Connexion.ProjetDB.Utilisateur
                       where x.Id_user == int.Parse(textBox1.Text)
                       select x;
            Utilisateur ut = lst3.Single<Utilisateur>(x => x.Id_user == int.Parse(textBox1.Text));
            var lst2 = from x in Connexion.ProjetDB.UserCible
                       where x.Id_user == int.Parse(textBox1.Text)
                       select x;
            UserCible us = lst2.First<UserCible>(x => x.Id_user == int.Parse(textBox1.Text));
            var lst1 = from y in Connexion.ProjetDB.Planing
                       where y.Id_usercreator == us.Id_usercible
                       select y;
            Planing pl = lst1.First<Planing>(x => x.Id_usercreator == us.Id_usercible);
            var lst0 = (from z in Connexion.ProjetDB.Tache
                        join z1 in lst1
                        on z.Id_planing equals z1.Id_planing
                        select z).ToList();
            dataGridView1.DataSource = lst0;
        }
    }
}
