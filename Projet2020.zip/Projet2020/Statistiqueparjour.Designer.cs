﻿namespace Projet2020
{
    partial class Statistiqueparjour
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Statistiqueparjour));
            this.button1 = new System.Windows.Forms.Button();
            this.btn_circulaire = new System.Windows.Forms.Button();
            this.Charger = new System.Windows.Forms.Button();
            this.diag_circulaire = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.diag_barre = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            ((System.ComponentModel.ISupportInitialize)(this.diag_circulaire)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diag_barre)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(420, 405);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Imprimer";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_circulaire
            // 
            this.btn_circulaire.Location = new System.Drawing.Point(664, 405);
            this.btn_circulaire.Name = "btn_circulaire";
            this.btn_circulaire.Size = new System.Drawing.Size(76, 23);
            this.btn_circulaire.TabIndex = 8;
            this.btn_circulaire.Text = "Charger";
            this.btn_circulaire.UseVisualStyleBackColor = true;
            this.btn_circulaire.Click += new System.EventHandler(this.btn_circulaire_Click);
            // 
            // Charger
            // 
            this.Charger.Location = new System.Drawing.Point(187, 405);
            this.Charger.Name = "Charger";
            this.Charger.Size = new System.Drawing.Size(75, 23);
            this.Charger.TabIndex = 7;
            this.Charger.Text = "Charger";
            this.Charger.UseVisualStyleBackColor = true;
            this.Charger.Click += new System.EventHandler(this.Charger_Click);
            // 
            // diag_circulaire
            // 
            chartArea1.Name = "ChartArea1";
            this.diag_circulaire.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.diag_circulaire.Legends.Add(legend1);
            this.diag_circulaire.Location = new System.Drawing.Point(454, 32);
            this.diag_circulaire.Name = "diag_circulaire";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Legend = "Legend1";
            series1.Name = "Tache";
            this.diag_circulaire.Series.Add(series1);
            this.diag_circulaire.Size = new System.Drawing.Size(474, 355);
            this.diag_circulaire.TabIndex = 6;
            this.diag_circulaire.Text = "chart2";
            title1.Name = "Title1";
            title1.Text = "Diagramme circulaire";
            this.diag_circulaire.Titles.Add(title1);
            // 
            // diag_barre
            // 
            chartArea2.Name = "ChartArea1";
            this.diag_barre.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.diag_barre.Legends.Add(legend2);
            this.diag_barre.Location = new System.Drawing.Point(19, 32);
            this.diag_barre.Name = "diag_barre";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Tacheparjour";
            this.diag_barre.Series.Add(series2);
            this.diag_barre.Size = new System.Drawing.Size(438, 355);
            this.diag_barre.TabIndex = 5;
            this.diag_barre.Text = "chart1";
            title2.Name = "Title1";
            title2.Text = "Diagramme en barre";
            this.diag_barre.Titles.Add(title2);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load_1);
            // 
            // Statistiqueparjour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_circulaire);
            this.Controls.Add(this.Charger);
            this.Controls.Add(this.diag_circulaire);
            this.Controls.Add(this.diag_barre);
            this.Name = "Statistiqueparjour";
            this.Text = "Statistiqueparjour";
            ((System.ComponentModel.ISupportInitialize)(this.diag_circulaire)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diag_barre)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_circulaire;
        private System.Windows.Forms.Button Charger;
        private System.Windows.Forms.DataVisualization.Charting.Chart diag_circulaire;
        private System.Windows.Forms.DataVisualization.Charting.Chart diag_barre;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}