﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Informationsconjoint : Form
    {
        internal static Conjoint cjt = new Conjoint();
        public Informationsconjoint()
        {
            InitializeComponent();
        }

        private void bt_planingconjoint_Click(object sender, EventArgs e)
        {
            Conjoint c = new Conjoint();
            c.etat_sante = cmb_etatsante.Text;
            c.fonction = txt_fonction.Text;
            Planningdujour p = new Planningdujour();
            p.ShowDialog();
            this.Close();
           // c.Id_planing = Planningdujour.pln.Id_planing; //p.pln.Id_planing;
            try
            {
                Connexion.ProjetDB.Conjoint.InsertOnSubmit(c);
                Connexion.ProjetDB.SubmitChanges();
                MessageBox.Show("Informations conjoint en régistré avec succés.");
                cjt = c;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Informationsconjoint_Load(object sender, EventArgs e)
        {

        }
    }
}
