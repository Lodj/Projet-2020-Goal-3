﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Acceuil : Form
    {
        public Acceuil()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Statistiqueparjour stat1 = new Statistiqueparjour();
            stat1.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Statistiquemensuel stat2 = new Statistiquemensuel();
            stat2.ShowDialog();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Statistiqueannuel stat3 = new Statistiqueannuel();
            stat3.ShowDialog();
        }
    }
}
