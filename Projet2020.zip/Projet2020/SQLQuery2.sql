﻿CREATE TABLE Utilisateur
(
	Id_Utilisateur INT NOT NULL PRIMARY KEY, 
    login_user VARCHAR(50) NOT NULL, 
    Mot_de_passe VARCHAR(50) NOT NULL, 
    Nom VARCHAR(50) NOT NULL, 
    Prenom VARCHAR(50) NOT NULL, 
    Date_naissance DATE NOT NULL, 
    Genre BIT NOT NULL, 
    Photo IMAGE NOT NULL, 
    Fonction VARCHAR(50) NOT NULL, 
    Adresse_mail VARCHAR(50) NOT NULL, 
    Adresse sys.geography NOT NULL, 
    Etat Civil VARCHAR(50) NOT NULL, 
    Nbre_enfrant INT NOT NULL, 
    Id_conjoint INT REFERENCES Informationconjoint(Id_conjoint),
    Id_enfant INT REFERENCES Informationenfant(Id_enfant), ,
    Id_parent INT REFERENCES Informationparent(Id_parent),
)
CREATE TABLE Tache
(
    Id_tache INT NOT NULL,
    Nom_tache VARCHAR(50) NOT NULL,
    Date_debut DATETIME ,
    Date_fin DATETIME,
    Duree_tolerance TIME,
    Emplacement VARCHAR(50),
    Personne_implique TEXT,
    Description_0 VARCHAR(50),
    Type_tache VARCHAR(50)
)
CREATE TABLE Planing
(
    Id_planing INT,
    Id_Utilisateur INT,
    Id_tache INT
)
CREATE TABLE Informationconjoint
(
    Id_conjoint INT,
    Id_planing INT,
    Id_tache INT,
)
CREATE TABLE Informationenfant
(
    Id_enfant INT,
    Niveau_etude VARCHAR(50),
    Nom_ecole VARCHAR(2),
    Distance_ecole_maison INT,
    Id_planing INT
)
CREATE TABLE Informationparent
(
    Id_parent INT,
    Id_planing INT,
)
