﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class InformationEnfantParent : Form
    {
        internal static Enfant en = new Enfant();
        internal static Parent par = new Parent();

        public InformationEnfantParent()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void bt_planingenfant_Click(object sender, EventArgs e)
        {
            Planningdujour enfant = new Planningdujour();
            Enfant e1 = new Enfant();
            //e1.Id_parent = Inscription.user.Id_user; //(use.Id_user) - 1;
            e1.niveau_etude = this.cmb_niveau.Text;
            e1.nom_ecole = this.txt_nomecole.Text;
            e1.distance_ecole_maison = double.Parse(this.txt_distance.Text);
            enfant.ShowDialog();
            //e1.Id_planing = Planningdujour.pln.Id_planing;
            try
            {
                Connexion.ProjetDB.Enfant.InsertOnSubmit(e1);
                Connexion.ProjetDB.SubmitChanges();
                MessageBox.Show("Informations enfants ajouté avec succés");
                en = e1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void InformationEnfantParent_Load(object sender, EventArgs e)
        {

        }
    }
}
