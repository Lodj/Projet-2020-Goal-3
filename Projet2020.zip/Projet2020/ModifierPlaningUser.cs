﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class ModifierPlaningUser : Form
    {
        public ModifierPlaningUser()
        {
            InitializeComponent();
        }

        private void bt_enregistrer_Click(object sender, EventArgs e)
        {
            Boolean verif = true;
            if (txt_login01.Text == "")
            {
                label13.Visible = true;
                verif = false;
            }
            if (txt_prenom.Text == "")
            {
                label14.Visible = true;
                verif = false;
            }
            if (txt_nom.Text == "")
            {
                label15.Visible = true;
                verif = false;
            }

            if (!rd_masculin.Checked && !rd_feminin.Checked)
            {
                label17.Visible = true;
                verif = false;
            }
            if (txt_fonction01.Text == "")
            {
                label18.Visible = true;
                verif = false;
            }
            if (txt_mail.Text == "")
            {
                label19.Visible = true;
                verif = false;
            }
            if (txt_adresse.Text == "")
            {
                label20.Visible = true;
                verif = false;
            }
            if (!rd_marie.Checked && !rd_celibataire.Checked)
            {
                label21.Visible = true;
                verif = false;
            }

            if (rd_marie.Checked)
            {
                label22.Visible = true;
            }


            if (!rd_vivantavecparent.Checked && !rd_nevinantpasavecparent.Checked)
            {
                label23.Visible = true;
                verif = false;
            }

            if (txt_motdepasse.Text == "")
            {
                label24.Visible = true;
                verif = false;
            }
            if (textBox1.Text == "")
            {
                label26.Visible = true;
                verif = false;
            }

            //Remplissage du LINQ; de notre base de données
            if (verif == true)
            {
                try
                {
                    Utilisateur u = Connexion.ProjetDB.Utilisateur.Single<Utilisateur>(x => x.Id_user == int.Parse(textBox1.Text));
                    if (u == null)
                    {
                        throw new Exception("Veuillez vérifier l'identifiant: parent n'existe pas.");
                    }
                    else
                    {
                        u.login = txt_login01.Text;
                        u.password = txt_motdepasse.Text;
                        u.nom = txt_nom.Text;
                        u.prenom = txt_prenom.Text;
                        u.date_naiss = dtp_datenaiss.Value;
                        if (rd_masculin.Checked == true)
                            u.genre = "Masculin";
                        else
                            u.genre = "Feminin";
                        u.fonction = txt_fonction01.Text;
                        u.mail = txt_mail.Text;
                        u.adress = txt_adresse.Text;
                        Connexion.ProjetDB.SubmitChanges();
                        MessageBox.Show("Modificaion éffectuée avec succé.");

                    }
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
            }  
        }

        private void rd_marie_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_marie.Checked)
            {
                label9.Visible = true;
                txt_nbreenfant.Visible = true;
                // label22.Visible = true;
            }
        }

        private void rd_celibataire_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_celibataire.Checked)
            {
                label9.Visible = false;
                txt_nbreenfant.Visible = false;
                label22.Visible = false;
            }
        }
    }
}
