﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Statistiqueparjour : Form
    {
        public Statistiqueparjour()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        /* private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
         {
             e.Graphics.DrawString(chart1, Font, Brushes.Black, 100, 100);
         }*/

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void Charger_Click(object sender, EventArgs e)
        {
            using (Projet2020Entities db = new Projet2020Entities())
            {

                diag_barre.DataSource = db.Taches.ToList();
                diag_barre.Series["Tacheparjour"].XValueMember = "Id_planing";
                diag_barre.Series["Tacheparjour"].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
                diag_barre.Series["Tacheparjour"].YValueMembers = "date_debut";
                diag_barre.Series["Tacheparjour"].YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            }
        }

        Bitmap bmp;
        private void button1_Click_1(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            bmp = new Bitmap(this.Size.Width, this.Size.Height, g);
            Graphics mg = Graphics.FromImage(bmp);
            mg.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, this.Size);
            printPreviewDialog1.ShowDialog();
        }

        private void printPreviewDialog1_Load_1(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(bmp, 0, 0);
        }

        private void btn_circulaire_Click(object sender, EventArgs e)
        {
            using (Projet2020Entities db = new Projet2020Entities())
            {

                diag_circulaire.DataSource = db.Taches.ToList();
                diag_circulaire.Series["Tache"].XValueMember = "Id_planing";
                diag_circulaire.Series["Tache"].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
                diag_circulaire.Series["Tache"].YValueMembers = "date_fin";
                diag_circulaire.Series["Tache"].YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            }
        }
    }
}
