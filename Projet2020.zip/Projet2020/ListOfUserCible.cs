﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class ListOfUserCible : Form
    {
        public ListOfUserCible()
        {
            InitializeComponent();
        }

        private void ListOfUserCible_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            var lst = from x in Connexion.ProjetDB.UserCible
                      select x;
            dataGridView1.DataSource = lst;
        }
    }
}
