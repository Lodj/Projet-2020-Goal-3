﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class ListOfPlanings : Form
    {
        public ListOfPlanings()
        {
            InitializeComponent();
        }

        private void ListOfPlanings_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            var lst = from x in Connexion.ProjetDB.Planing
                      select x;
            dataGridView1.DataSource = lst;
        }
    }
}
