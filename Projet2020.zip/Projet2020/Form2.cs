﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void conjointToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AjoutConjoint c = new AjoutConjoint();
            c.MdiParent = this;
            c.Show();
        }

        private void monPlaningToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AfficharPlaning aff = new AfficharPlaning();
            aff.MdiParent = this;
            aff.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AjoutParent p = new AjoutParent();
            p.MdiParent = this;
            p.Show();
            //this.Hide();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            DeleteParent s = new DeleteParent();
            s.MdiParent = this;
            s.Show();
            //this.Hide();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            ModifierParent m = new ModifierParent();
            m.MdiParent = this;
            m.Show();
        }

        private void suprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteConjoint c = new DeleteConjoint();
            c.MdiParent= this;
            c.Show();
        }

        private void modifierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ModifierConjoint modif = new ModifierConjoint();
            modif.MdiParent= this;
            modif.Show();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            AjoutEnfant en = new AjoutEnfant();
            en.MdiParent = this;
            en.Show();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            DeleteEnfant dl = new DeleteEnfant();
            dl.MdiParent = this;
            dl.Show();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            ModifierEnfant m1 = new ModifierEnfant();
            m1.MdiParent = this;
            m1.Show();
        }

        private void ajouterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AjoutPlaningUser a = new AjoutPlaningUser();
            a.MdiParent = this;
            a.Show();
        }

        private void consulterToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void supprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeletePlaning dp = new DeletePlaning();
            dp.MdiParent = this;
            dp.Show();
        }

        private void modifierToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ModifierPlaning m1 = new ModifierPlaning();
            m1.MdiParent = this;
            m1.Show();
        }

        private void ajouterToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            DeletePlaningUser dl = new DeletePlaningUser();
            dl.MdiParent = this;
            dl.Show();
        }

        private void familleToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void parentToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void modifierToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ModifierPlaningUser m0 = new ModifierPlaningUser();
            m0.MdiParent = this;
            m0.Show();
        }

        private void parJourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Statistiqueparjour s = new Statistiqueparjour();
            s.MdiParent = this;
            s.Show();
        }

        private void parAnnéeToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void reconnaissanceVocaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Reconnaissance_vocale r = new Reconnaissance_vocale();
            r.MdiParent = this;
            r.Show();
        }

        private void conjointToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ListConjoint l = new ListConjoint();
            l.MdiParent = this;
            l.Show();
        }

        private void parentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ListParent l = new ListParent();
            l.MdiParent = this;
            l.Show();
        }

        private void enfantToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ListEnfant l = new ListEnfant();
            l.MdiParent = this;
            l.Show();
        }

        private void utilisateurToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListofUser l = new ListofUser();
            l.MdiParent = this;
            l.Show();
        }

        private void usercibleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListOfUserCible l = new ListOfUserCible();
            l.MdiParent = this;
            l.Show();
        }

        private void planingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListOfPlanings l = new ListOfPlanings();
            l.MdiParent = this;
            l.Show();
        }

        private void tacheToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListOfTasks l = new ListOfTasks();
            l.MdiParent = this;
            l.Show();
        }
    }
}
